<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Data Absen</h1>
    <p><strong>ID Absen:</strong> {{ $id_absen }}</p>
    <p><strong>Nama Pegawai:</strong> {{ $nama_pegawai }}</p>
    <p><strong>Jam Masuk:</strong> {{ $jam_masuk }}</p>
    <p><strong>Jam Pulang:</strong> {{ $jam_pulang }}</p>
    <p><strong>Tanggal:</strong> {{ $created_at }}</p>
</body>
</html>
